package com.example.victim.chatsapp;

/**
 * Created by victim on 30/3/17.
 */


public class UserDetails {
    static String username = "";
    static String password = "";
    static String chatWith = "";
    static String encoded="";
}